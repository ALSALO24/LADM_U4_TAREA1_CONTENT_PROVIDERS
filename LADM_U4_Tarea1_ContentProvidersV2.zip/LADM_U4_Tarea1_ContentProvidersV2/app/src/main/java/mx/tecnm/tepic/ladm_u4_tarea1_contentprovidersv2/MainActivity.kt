package mx.tecnm.tepic.ladm_u4_tarea1_contentprovidersv2

import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.CalendarContract
import android.widget.ArrayAdapter
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_main.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.jar.Manifest
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {
    var siPermiso = 1
    var tipollamada:List<String> = listOf<String>("Entrantes", "Salientes","Perdidas","Correo de Voz","Rechazados","bloqueados","Externos")

    var siPermisoEvento = 2
    var evento = listOf(CalendarContract.Events._ID,CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART).toTypedArray()
    var listaEventos = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttonLlamadas.setOnClickListener {
            if(ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_CALL_LOG)!= PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.READ_CALL_LOG), siPermiso)
            }else{
                llenarRegistrosLlamadas()
            }//
        }//buttonLlamadas

        botonEventos.setOnClickListener{
            if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_DENIED){
                ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.READ_CALENDAR), siPermisoEvento)
            }else{
                llenarRegistroEventos()
            }
        }
    }//onCreate

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == siPermisoEvento){
            llenarRegistroEventos()
        }
        if(requestCode == siPermiso){
            llenarRegistrosLlamadas()
        }

    }


    private fun llenarRegistroEventos() {
        val dato = "((${CalendarContract.Calendars.ACCOUNT_NAME} = ?) AND" +
                "(${CalendarContract.Calendars.ACCOUNT_TYPE} = ?) AND" +
                "(${CalendarContract.Calendars.OWNER_ACCOUNT} = ?))"
        val parametros = arrayOf("alsalo243@gmail.com", "com.google","alsalo243@gmail.com")
        val cursor = contentResolver.query(CalendarContract.Events.CONTENT_URI,
        evento, dato, parametros, null
        )!!
        listaEventos.clear()
        if (cursor.moveToFirst()){
            val posTitulo = cursor.getColumnIndex(CalendarContract.Events.TITLE)
            val posFecha = cursor.getColumnIndex(CalendarContract.Events.DTSTART)

            do {
                val fecha = convertirFecha(cursor.getLong(posFecha))
                listaEventos.add("Titulo: ${cursor.getString(posTitulo)}\n"+
                "Fecha: ${fecha}")

            }while (cursor.moveToNext())
        }else{
            listaEventos.add("No hay eventos proximos")
        }

        listaLlamadas.adapter = ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,listaEventos)
    }

    private fun convertirFecha(fecha: Long): String {
        if (fecha == null) return ""
        val calendario = Calendar.getInstance(Locale.getDefault())
        calendario.timeInMillis = fecha
        return android.text.format.DateFormat.format("dd MM yyyy", calendario).toString()

    }

    private fun llenarRegistrosLlamadas() {
        var cursor =contentResolver.query(Uri.parse("content://call_log/calls"),null,null,null,null)
        var registros:ArrayList<String> = ArrayList<String>()
        var obtenerTipo = ""

        if(cursor!!.moveToFirst()){
            var numero =cursor.getColumnIndex("NUMBER")
            var tipo =cursor.getColumnIndex("TYPE")
            var fecha = cursor.getColumnIndex("DATE")
            do{
                val fechas = SimpleDateFormat("dd/MM/yy k:mm")
                val currentDate = fechas.format(cursor.getLong(fecha))
                obtenerTipo =tipollamada.get(cursor.getString(tipo).toInt())

                registros.add("Numero: "+cursor.getString(numero)+"\nTipo: "+obtenerTipo+"\nFecha: "+currentDate+"\n")
            }while(cursor.moveToNext())//while
        }//if
        else{
            registros.add("No hay registros de llamadas")
        }
        listaLlamadas.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, registros)
    }
}